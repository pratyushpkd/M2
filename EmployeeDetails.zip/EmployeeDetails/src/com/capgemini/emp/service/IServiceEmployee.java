package com.capgemini.emp.service;

import java.util.List;

import com.capgemini.emp.bean.EmployeeBean;
import com.capgemini.emp.exception.EmployeeException;

public interface IServiceEmployee 
{
public boolean insertEmployee(EmployeeBean EmployeeBean) throws EmployeeException;
	
	public List<EmployeeBean> viewAll() throws EmployeeException;
	
	public boolean updateEmployee
	(final int empid, final float salary,final String department,final String desn ) 
			throws EmployeeException;
	
	public boolean deleteEmployee(int empid) throws EmployeeException;
}
