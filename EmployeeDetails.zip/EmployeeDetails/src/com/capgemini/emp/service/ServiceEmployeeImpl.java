package com.capgemini.emp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.List;

import com.capgemini.emp.bean.EmployeeBean;
import com.capgemini.emp.dao.EmployeeDAOImpl;
import com.capgemini.emp.dao.IEmployeeDAO;
import com.capgemini.emp.exception.EmployeeException;


public class ServiceEmployeeImpl implements IServiceEmployee {

	public boolean insertEmployee(EmployeeBean employeeBean)
			throws EmployeeException 
	{
		boolean isItInserted=false;
		
		EmployeeBean employeeDAO=new EmployeeBean();
		ServiceEmployeeImpl service=new ServiceEmployeeImpl();
		isItInserted=service.insertEmployee(employeeBean);
		
		return isItInserted;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException 
	{
		return null;
	}

	@Override
	public boolean updateEmployee(int empid, float salary, String department,
			String desn) throws EmployeeException 
	{
		IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
		boolean isupdated=employeeDAO.updateEmployee(empid, salary, department, desn);
		return isupdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException 
	{
		IEmployeeDAO employeeDAO=new EmployeeDAOImpl();
		boolean isDeleted=employeeDAO.deleteEmployee(empid);
		return isDeleted;
	}

public boolean isValidName(String name) throws EmployeeException{
		
		boolean isValid=false;
		
		String pattern="[A-Z]{1}[a-z]{0,19}";
		
		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher=ptn.matcher(name);
		isValid=matcher.matches();
		
		if(!isValid)
			throw new EmployeeException("Invalid Name");
		
		return isValid;
		
	}
	
	public boolean isValidSalary(float salary) throws EmployeeException{
		
		boolean isValid=false;
		
		if(salary>0)
			isValid=true;
		
		if(!isValid)
			throw new EmployeeException("Salary Must Be Positive");
		
		return isValid;
		
	}
	
}
