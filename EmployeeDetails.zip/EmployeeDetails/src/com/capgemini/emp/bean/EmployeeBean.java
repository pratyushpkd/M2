package com.capgemini.emp.bean;

public class EmployeeBean 
{
	private int empid;
	private String empname;
	private float salary;
	private String dept;
	private String desn;
	
	
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(int empid,String empname, float salary, String dept, String desn) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.salary = salary;
		this.dept = dept;
		this.desn = desn;
		
	}
	
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getDesn() {
		return desn;
	}
	public void setDesn(String desn) {
		this.desn = desn;
	}
	
	
	@Override
	public String toString() {
		return "EmployeeBean [empname=" + empname + ", salary=" + salary
				+ ", dept=" + dept + ", desn=" + desn + ", empid=" + empid
				+ "]";
	}

	
	
	
}
