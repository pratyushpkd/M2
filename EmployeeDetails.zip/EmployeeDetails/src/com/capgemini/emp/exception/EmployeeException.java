package com.capgemini.emp.exception;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6159873561963918869L;

	public EmployeeException() 
	{
		super();
	}
	
	public EmployeeException(String message) 
	{
		super(message);
	}
}
