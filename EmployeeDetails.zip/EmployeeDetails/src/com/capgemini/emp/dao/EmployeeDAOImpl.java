package com.capgemini.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.emp.bean.EmployeeBean;
import com.capgemini.emp.exception.EmployeeException;
import com.capgemini.emp.util.DBConnection;


public class EmployeeDAOImpl implements IEmployeeDAO {

	@Override
	public boolean insertEmployee(EmployeeBean EmployeeBean)
			throws EmployeeException 
	{
		int records = 0;
		boolean isInserted = false;
		
		try(Connection connEmployeeDetails =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connEmployeeDetails.prepareStatement(QueryMapperEmployee.INSERT_EMPLOYEE);
				){
				
				preparedStatement.setString(1, EmployeeBean.getEmpname());
				preparedStatement.setFloat(2, EmployeeBean.getSalary());
				preparedStatement.setString(3, EmployeeBean.getDept());
				preparedStatement.setString(4, EmployeeBean.getDesn());
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isInserted = true;
				}
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public List<EmployeeBean> viewAll() throws EmployeeException 
	{
		List<EmployeeBean>employeeList = new ArrayList<EmployeeBean>();
		
		try(Connection connEmployee = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connEmployee.prepareStatement(QueryMapperEmployee.VIEW_EMPLOYEE);
				ResultSet rsEmployee = preparedStatement.executeQuery();
				){
			while(rsEmployee.next()){
				EmployeeBean emp1 = new EmployeeBean();
				
				emp1.setEmpid(rsEmployee.getInt("empid"));
				emp1.setEmpname(rsEmployee.getString("empname"));
				emp1.setSalary(rsEmployee.getFloat("salary"));
				emp1.setDept(rsEmployee.getString("department"));
				emp1.setDesn(rsEmployee.getString("desn"));
				
				employeeList.add(emp1);
			}
			
			if(employeeList.size()==0){
				throw new EmployeeException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		return employeeList;
	}

	@Override
	public boolean updateEmployee(int empid, float salary, String department,
			String desn) throws EmployeeException 
	{
		int records =0;
		boolean isUpdated = false;
		
		try(Connection connMobile = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connMobile.prepareStatement(QueryMapperEmployee.UPDATE_EMPLOYEE);
				){
			preparedStatement.setFloat(1,salary);
			preparedStatement.setString(2,department);
			preparedStatement.setString(3,desn);
			
			records = preparedStatement.executeUpdate();
			
			if(records >0){
				isUpdated= true;
			}
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		return isUpdated;
	}

	@Override
	public boolean deleteEmployee(int empid) throws EmployeeException 
	{
		int records=0;
		boolean isDeleted = false;
		
		try(Connection connPurchaseDetails = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement = 
				connPurchaseDetails.prepareStatement(QueryMapperEmployee.DELETE_EMPLOYEE);
				){
			preparedStatement.setInt(1, empid);
			
			records = preparedStatement.executeUpdate();
			
			if(records > 0){
				isDeleted = true;
			}
		}catch(SQLException sqlEx){
			throw new EmployeeException(sqlEx.getMessage());
		}
		
		return isDeleted;
	}

}
