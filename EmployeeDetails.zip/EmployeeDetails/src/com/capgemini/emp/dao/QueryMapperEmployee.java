package com.capgemini.emp.dao;

public interface QueryMapperEmployee 
{
	public static final String INSERT_EMPLOYEE =
			"INSERT INTO emp1 VALUES(empid_sequence.NEXTVAL,?,?,?,?)";
	
	public static final String VIEW_EMPLOYEE = 
			"SELECT empid, empname, salary, department, desn FROM emp1";
	
	public static final  String UPDATE_EMPLOYEE = 
			"UPDATE emp1 SET salary = ?,department= ?,desn =? WHERE empid= ?";
	
	public static final String DELETE_EMPLOYEE =
			"DELETE FROM emp1 where empid = ?";
}
