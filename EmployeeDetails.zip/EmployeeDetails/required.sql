CREATE TABLE emp1 (empid NUMBER PRIMARY KEY, empname VARCHAR2 (20), salary NUMBER(10,2),
department VARCHAR2(20), desn VARCHAR2(20));

CREATE SEQUENCE empid_sequence
START WITH 1;