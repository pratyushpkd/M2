create table employee(employeeid number(10) primary key, employeename varchar2(30), hiredate date, salary number(10), departmentname varchar2(20));


create sequence emp_sequence
start with 1001;