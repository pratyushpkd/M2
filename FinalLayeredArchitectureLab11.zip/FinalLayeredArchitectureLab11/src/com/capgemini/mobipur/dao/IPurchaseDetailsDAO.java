package com.capgemini.mobipur.dao;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public interface IPurchaseDetailsDAO {
	public boolean insertPurchase(PurchaseDetailsBean purchaseDetailsBean) throws MobilePurchaseException;
	
	public boolean deletePurchaseDetails(int mobileId) throws MobilePurchaseException;

}
