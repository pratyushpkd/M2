package com.capgemini.cab.exception;

public class CabException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7290476975593304142L;
	/**
	 * 
	 */
	public CabException(){
		super();
	}
	public CabException(String message) {
		super(message);
		
	}

}
