package com.capgemini.cab.service;

import com.capgemini.cab.bean.PurchaseDetailsBean;
import com.capgemini.cab.exception.CabException;

public interface IServicePurchaseMobile {
	
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)throws CabException;
		
	
}
