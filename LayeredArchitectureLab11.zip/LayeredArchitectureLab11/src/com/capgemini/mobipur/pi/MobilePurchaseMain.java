package com.capgemini.mobipur.pi;

import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mobipur.bean.MobileBean;
import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.ServiceMobileImpl;
import com.capgemini.mobipur.service.ServicePurchaseImpl;

public class MobilePurchaseMain {
	private static Logger logger=Logger.getRootLogger();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");

		boolean isInProcess = true;
		boolean isValid = false;
		
		byte choice = 0;
		
		String cname = null;
		String mailId = null;
		String phoneNo = null;
		int mobileId = 0;
		
		ServiceMobileImpl serviceMobile = new ServiceMobileImpl();
		ServicePurchaseImpl servicePurchaseMobile = new ServicePurchaseImpl();
		
		PurchaseDetailsBean purchaseDetailsBean = null;
		
		List<MobileBean>mobileList = null;
		
		Scanner scan = new Scanner(System.in);
		
		while (isInProcess){
			System.out.println("1. Insert Mobile Purchase.");
			System.out.println("2. View all Mobiles.");
			System.out.println("3. Delete mobile details.");
			System.out.println("4. Search mobiles for a range.");
			System.out.println("0. Exit");
			
			choice = Byte.parseByte(scan.nextLine());
			
			switch (choice){
			case 1:
				while(!isValid){
					try{
						System.out.println("Enter customer name: ");
						cname= scan.nextLine();
						
						isValid = servicePurchaseMobile.isValidCName(cname);
						
					}catch(MobilePurchaseException mpe){
						logger.error("Invalid name: " +cname);
						isValid = false;
					}
				}
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter mail ID: ");
						mailId= scan.nextLine();
						
						isValid = servicePurchaseMobile.isValidMail(mailId);
						
					}catch(MobilePurchaseException mpe){
						logger.error("Invalid mail ID: " +mailId);
						isValid = false;
					}
				}
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter Phone No. ");
						phoneNo= scan.nextLine();
						
						isValid = servicePurchaseMobile.isValidPhoneNo(phoneNo);
						
					}catch(MobilePurchaseException mpe){
						logger.error("Invalid Phone no.: " +phoneNo);
						isValid = false;
					}
				}
				
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter mobile ID: ");
						mobileId= Integer.parseInt(scan.nextLine());
						
						isValid = servicePurchaseMobile.isValidMobileId(mobileId);
						
					}catch(MobilePurchaseException mpe){
						logger.error("Invalid Mobile ID: " +mobileId);
						isValid = false;
					}
				}
				
				purchaseDetailsBean = new PurchaseDetailsBean(cname, mailId, phoneNo, mobileId);
				try{
					servicePurchaseMobile.insertPurchaseDetails(purchaseDetailsBean);
				}catch(MobilePurchaseException e){
					logger.error(e.getMessage());
				}
				break;
			
			case 2:
				try{
				mobileList = serviceMobile.viewAll();
					for (MobileBean mobileBean : mobileList){
						System.out.println(mobileBean);
					}
					System.out.println("====================================================================");
				}catch(MobilePurchaseException e){
					logger.error(e.getMessage());
				}
				break;
				
			case 3:
				isValid = false;
				
				while(!isValid){
					try{
						System.out.println("Enter mobile ID: ");
						mobileId= Integer.parseInt(scan.nextLine());
						
						isValid = servicePurchaseMobile.isValidMobileId(mobileId);
						
					}catch(MobilePurchaseException mpe){
						logger.error("Invalid Mobile ID: " +mobileId);
						isValid = false;
					}
				}
				
				try{
					boolean isDeleted = serviceMobile.deleteMobile(mobileId);
					if(isDeleted){
						System.out.println("Mobile record deleted successfully");
					}
				}catch(MobilePurchaseException e){
					logger.error(e.getMessage());
				}
				break;
			case 4:
				float minPrice = 0;
				float maxPrice = 0;
				
				System.out.println("Enter minimum price: ");
				minPrice = Float.parseFloat(scan.nextLine());
				System.out.println("Enter Maximum price: ");
				maxPrice = Float.parseFloat(scan.nextLine());
				try{
					mobileList = serviceMobile.search(minPrice, maxPrice);
					for(MobileBean mobileBean : mobileList){
						System.out.println(mobileBean);
					}
					System.out.println("===================================================================");
				}catch(MobilePurchaseException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 0:
				isInProcess = false;
				break;
			default:
				System.out.println("Invalid Input");
				logger.error("Invalid Input: " +choice);
			}
			
		}
		scan.close();
	}

}
