package com.capgemini.mobipur.service;

import java.util.regex.Pattern;

import com.capgemini.mobipur.bean.PurchaseDetailsBean;
import com.capgemini.mobipur.dao.IMobileDAO;
import com.capgemini.mobipur.dao.IPurchaseDetailsDAO;
import com.capgemini.mobipur.dao.MobileDAOImpl;
import com.capgemini.mobipur.dao.PurchaseDetailsDAOImpl;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailsBean purchaseDetailsBean)
			throws MobilePurchaseException {
		int mobileQuantity = 0;
		boolean isItInserted = false;
		boolean isUpdated = false;
		
		IPurchaseDetailsDAO purchaseDetailsDAO = new PurchaseDetailsDAOImpl() ;
		IMobileDAO mobileDAO = new MobileDAOImpl();	
		
		mobileQuantity = mobileDAO.getQuntity(purchaseDetailsBean.getMobileId());
		
		if(mobileQuantity > 0){
			isItInserted = purchaseDetailsDAO.insertPurchase(purchaseDetailsBean);
			mobileQuantity--;
			isUpdated = mobileDAO.updateMobile(purchaseDetailsBean.getMobileId(), mobileQuantity);
		}	
		return (isItInserted && isUpdated);
		
	}
	public boolean isValidCName(String cname) throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern ="[A-Z]{1}[A-Za-z]{,19}";
		
		
		isValid = Pattern.matches(cname, pattern);
		
		if(!isValid){
			throw new MobilePurchaseException("Invalid name");
		}
		
		return isValid;
	}
	public boolean isValidPhoneNo(String phoneNo)throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern ="[\\d]{10}";
		
		
		isValid = Pattern.matches(phoneNo, pattern);
		if(!isValid){
			throw new MobilePurchaseException("Phone no. must be of 10 digits");
		}
		return isValid;
	}
	public boolean isValidMail(String mail) throws MobilePurchaseException{
		boolean isValid = false;
		
		String pattern ="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";
		
		
		isValid = Pattern.matches(mail, pattern);
		if(!isValid){
			throw new MobilePurchaseException("Enter valid mail id");
			
		}
		return isValid;
	}
	public boolean isValidMobileId(int mobileId)throws MobilePurchaseException{
		boolean isValid = false;
		String mobile = Integer.toString(mobileId);
		String pattern ="[\\d]{4}";
		
		
		isValid = Pattern.matches(mobile, pattern);
		if(!isValid){
			throw new MobilePurchaseException("Mobile idmust contain atleast 4 digits");
			
		}
		return isValid;
	}
}
